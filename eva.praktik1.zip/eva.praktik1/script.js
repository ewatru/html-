const cardsData = [
    {
      image: "images/listing-01-image (2).png",
      title: "Brightwoods Cabins",
      rating: "4.9",
      location: "Bridlepath, Ontario, Canada",
      price: "$658"
    },
    {
      image: "images/listing-02-image.png",
      title: "Mississauga Aistream",
      rating: "4.8",
      location: "Mississauga, Ontario, Canada",
      price: "$502"
    },
    {
      image: "images/listing-03-image.png",
      title: "Urban Loft",
      rating: "4.5",
      location: "Georgina Bay, Ontario, Canada",
      price: "$410"
    },
    {
      image: "images/listing-04-image.png",
      title: "Forestville Cottages",
      rating: "5.0",
      location: "Simcoe, Ontario, Canada",
      price: "$325"
    },
    {
      image: "images/listing-05-image.png",
      title: "Unionville Logde",
      rating: "4.8",
      location: "Markham, Ontario, Canada",
      price: "$485"
    },
    {
      image: "images/listing-06-image.png",
      title: "Niagara Homes",
      rating: "4.9",
      location: "Niagara, Ontario, Canada",
      price: "$655"
    },
    {
      image: "images/listing-07-image.png",
      title: "Sunny Estate",
      rating: "5.0",
      location: "Barcclrt, Ontario, Canada",
      price: "$320"
    },
    {
      image: "images/listing-08-image.png",
      title: "Lawrence Hills",
      rating: "5.0",
      location: "Lawrence, Ontario, Canada",
      price: "$350"
    },
    {
      image: "images/listing-09-image.png",
      title: "Simcoe Lake Lodge",
      rating: "5.0",
      location: "Simcoe, Ontario, Canada",
      price: "$395"
    },
    {
      image: "images/listing-10-image.png",
      title: "Wasaga Beach Home",
      rating: "5.0",
      location: "Georgina Bay, Ontario, Canada",
      price: "$385"
    },
    {
      image: "images/listing-11-image.png",
      title: "Banff Hills",
      rating: "5.0",
      location: "Banff, Alberta, Canada",
      price: "$385"
    },
    {
      image: "images/listing-12-image.png",
      title: "Creemore Canada",
      rating: "5.0",
      location: "Creemore, Alberta, Canada",
      price: "$385"
    },
    {
      image: "images/listing-13-image.png",
      title: "Kawartha Lakes",
      rating: "5.0",
      location: "Kawartha, Alberta, Canada",
      price: "$385"
    },
    {
      image: "images/listing-14-image.png",
      title: "Revelstoke Cabin",
      rating: "5.0",
      location: "Revelstoke, Alberta, Canada",
      price: "$385"
    },
    {
      image: "images/listing-15-image.png",
      title: "Brightwoods Estate",
      rating: "5.0",
      location: "Brightwoods Estate",
      price: "$385"
    }
  ];
  

  const container = document.getElementById('cards-container');
  

  cardsData.forEach(item => {
    const cardElement = document.createElement('div');
    cardElement.className = 'card';
  
    cardElement.innerHTML = `
      <div class="card_image">
        <img src="${item.image}" alt="${item.title}">
        <button class="wishlist">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
      </div>
    
      <div class="card_info">
        <div class="card_header">
          <h3 class="card_title">${item.title}</h3>
          <div class="card_rating">
            <span class="value">${item.rating}</span>
            <span class="star">★</span>
          </div>
        </div>
    
        <p class="location">${item.location}</p>
    
        <div class="card_price">
          <span class="price">${item.price}</span>
          <span class="period">/night</span>
        </div>
      </div>
    `;
  
    container.appendChild(cardElement);
  });
  